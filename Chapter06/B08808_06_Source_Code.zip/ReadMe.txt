Chatper 7 Code Solutions Read Me
================================================================================================

1. Restore Packages using Nuget Restore.If you have to verify specific package version, please refer individual project's pacakge.config file.
2. Set Both 'TodoListService' and 'ToDoListWebApp' projects as startup. You can do this with right clicking solution and then using startup option.
3. This Code sample requires Azure Active Directory Setup. For setting it up and configurations, refer to chapter 7.