﻿namespace FlixOne.BookStore.ProductService
{
    public class Constant
    {
        public const string Version = "2.0.0"; //API version
    }
}