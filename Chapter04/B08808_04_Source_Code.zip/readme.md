# Chapter 4: Integration Techniques and Microservices #

## Description ##

<<Description goes here>>

## How to start? ##
Follow these steps:

* Open Visual Studio 2017 update 3 or later
* File -> Open [ctrl + shift + O]
* Go to [Day04](/Day04/source%20code/Day04) click on solution and then click open	
* Click on Run or press F5
* Select appropriate option from the screen and run the code