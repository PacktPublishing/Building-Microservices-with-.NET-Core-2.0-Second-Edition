﻿namespace FlixOne.BookStore.OrderService.Common
{
    //appsettings.json fetcher class
    public class AppSettings
    {
        public string ProductServiceUri { get; set; }
    }
}